This is where you're supposed to put your custom DS Borders.

To add your DS Border to the list, make a list.txt file on this folder and add the exact DS Border image file name.
If you want to add multiple borders, do it like this:

My Border 1
My Border 2
My Border 3