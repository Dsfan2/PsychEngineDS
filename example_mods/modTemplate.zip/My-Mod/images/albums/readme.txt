Put your custom album covers for Freeplay here.

The MUST be 700x700 in order to work properly!