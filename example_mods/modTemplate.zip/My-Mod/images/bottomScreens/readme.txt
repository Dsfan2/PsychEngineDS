Add your bottom screen images here. They are to be used when DS Filter is on.

Your images MUST be named the same as your custom stage