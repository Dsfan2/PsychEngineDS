Add your Philly Glow foreground images here. They are to be used when Philly Glow is active.

Your images MUST be named the same as your custom stage