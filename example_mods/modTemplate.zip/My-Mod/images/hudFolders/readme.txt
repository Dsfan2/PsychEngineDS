This is where you're supposed to put your custom hud folders.
Your hud folder must be named like this:

My HudUI

To add your custom hud to the list, make a list.txt file on this folder and add your hud folder name, if you want to add multiple custom huds, do it like this:

My Hud 1
My Hud 2
My Hud 3