Put your custom character icons here!
You MUST have 3 frames on your icons image otherwise it might not load properly.
Recommended resolution: 450x150