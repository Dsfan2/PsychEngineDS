This is where you're supposed to put your Note Skins.
Note skins need 2 files with the same names:

My Skin.png
My Skin.xml

To add your note skin to the list, make a list.txt file on this folder and add your note skin file name, if you want to add multiple skins, do it like this:

My Skin 1
My Skin 2
My Skin 3

If you're adding custom Hurt Note skins or Extra Note skins, put them in the 'HURT' or 'EXTRA' folders respectively
and the files must be the same as the skin name but with a specific prefix before them. For example:
For Hurt Notes: HURTMy Skin.png / HURTMy Skin.xml
For Extra Notes: EXTRAMy Skin.png / EXTRAMy Skin.xml