This is for the pixel variants of your custom huds

All images MUST end with -pixel