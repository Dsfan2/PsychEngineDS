This is for the pixel variants of your custom note skins
There must be two files present:

My Skin.png
My SkinENDS.png