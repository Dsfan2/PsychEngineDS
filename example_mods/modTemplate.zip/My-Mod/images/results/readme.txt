Add your results screen sprites here.

Use the "player1_sprites" "player2_sprites" or "player3_sprites" in the non-mod results folder as a guide.