Put your GLOBAL .lua and/or .hx scripts here.

They will apply to EVERY SONG LOADED. Be mindful of that.