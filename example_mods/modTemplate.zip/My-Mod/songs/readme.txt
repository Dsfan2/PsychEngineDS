Put your custom songs here
It should be a folder with your custom song's name, and inside of it should include at least two files: "Inst.ogg" and "Voices.ogg"
If you have Voices Files for the other player characters put in "VoicesP2.ogg" & "VoicesP3.ogg"