These are template scripts for various things.

TemplateScript.lua		- Example LUA Script for PlayState
TemplateScript.hx		- Example HX Script for PlayState
TemplateMainMenuScript.lua	- Example LUA Script for MainMenuState
TemplateMainMenuScript.hx	- Example HX Script for MainMenuState
TemplateFreeplayScript.lua	- Example LUA Script for FreeplayState
TemplateFreeplayScript.hx	- Example HX Script for FreeplayState
achievementsTemplate.json	- Example JSON file for custom achievements
settingsTemplate.json		- Example JSON file for mod settings