Drop your custom week .json files here!

Create a .txt file called "weekList.txt" for putting your week files in a specific order.