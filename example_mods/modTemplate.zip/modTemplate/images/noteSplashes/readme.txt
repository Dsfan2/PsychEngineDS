This is where you're supposed to put your Note Splashes.
Note splashes need 3 files with the same names:

My Skin.txt - You can make it through the Note Splash Debug (press 7 on Main Menu)
My Skin.png
My Skin.xml

To add your note splash to the list, make a list.txt file on this folder and add your splash skin file name, if you want to add multiple skins, do it like this:

My Skin 1
My Skin 2
My Skin 3